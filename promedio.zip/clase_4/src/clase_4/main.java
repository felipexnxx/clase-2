package clase_4;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		Scanner scan = new Scanner (System. in);
		String name1, name2;
		double not1, not2, not3, note1, note2, note3;
		double promedio=3.0;
		double resultado1, resultado2;
		
		try 
		{
			System.out.println("Ingrese los datos del primer estudiante");
			System.out.println("Nombre del Primer estudiante");
			name1 = scan.next();
			System.out.println("Ingrese las notas del primer estudiante");
			System.out.println("Primer nota");
			not1 = scan.nextDouble();
			System.out.println("Segunda nota");
			not2 = scan.nextDouble();
			System.out.println("Tercer nota");
			not3 = scan.nextDouble();
			System.out.println("Ingrese las notas del segundo estudiante");
			System.out.println("Nombre del segundo estudiante");
			name2 = scan.next();
			System.out.println("Primer nota");
			note1 = scan.nextDouble();
			System.out.println("Segunda nota");
			note2 = scan.nextDouble();
			System.out.println("Tercer nota");
			note3 = scan.nextDouble();
			resultado1=Math.round((not1+not2+not3)/promedio);
			resultado2=Math.round((note1+note2+note3)/promedio);
			System.out.println(name1+","+"Promedio:"+resultado1);
			System.out.println(name2+","+"Promedio:"+resultado2);
			
			
			
			
		}
		catch(Exception e)
		{
			System.out.println("Verifique que los datos esten correctos, o la division entre 0 no existe");
		}
	}
	
}
